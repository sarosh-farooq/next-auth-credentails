import { ReactNode } from "react";

interface Tech {
    title: string;
    icon: ReactNode;
    link: string;
}